"""ShapeNet part-segmentation experiments."""
