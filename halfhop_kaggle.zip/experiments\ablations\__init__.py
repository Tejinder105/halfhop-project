"""Ablation experiments package."""
